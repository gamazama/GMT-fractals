
import { featureRegistry } from '../engine/FeatureSystem';
import { AtmosphereFeature } from './atmosphere/index'; 
import { DrosteFeature } from './droste';
import { MaterialFeature } from './materials';
import { ColorGradingFeature } from './color_grading';
import { TexturingFeature } from './texturing';
import { ColoringFeature } from './coloring';
import { GeometryFeature } from './geometry';
import { QualityFeature } from './quality';
import { CoreMathFeature } from './core_math';
import { LightingFeature } from './lighting/index';
import { OpticsFeature } from './optics';
import { NavigationFeature } from './navigation';
import { AudioFeature } from './audioMod';
import { DrawingFeature } from './drawing/index';
import { ModulationFeature } from './modulation';
import { WebcamFeature } from './webcam';
import { DebugToolsFeature } from './debug_tools';
import { EngineSettingsFeature } from './engine/index';
import { AOFeature } from './ao/index';
import { ReflectionsFeature } from './reflections/index';
import { WaterPlaneFeature } from './water_plane';

// --- REGISTER FEATURES ---
export const registerFeatures = () => {
    // Core
    featureRegistry.register(CoreMathFeature);
    featureRegistry.register(GeometryFeature);
    
    // Rendering & Shading
    featureRegistry.register(LightingFeature);
    featureRegistry.register(AOFeature);
    featureRegistry.register(ReflectionsFeature);
    featureRegistry.register(AtmosphereFeature);
    featureRegistry.register(MaterialFeature);
    featureRegistry.register(WaterPlaneFeature); // Registered here
    featureRegistry.register(ColoringFeature);
    featureRegistry.register(TexturingFeature);
    featureRegistry.register(QualityFeature);
    
    // Post & Effects
    featureRegistry.register(DrosteFeature);
    featureRegistry.register(ColorGradingFeature);
    
    // Scene
    featureRegistry.register(OpticsFeature);
    featureRegistry.register(NavigationFeature);
    
    // Systems
    featureRegistry.register(AudioFeature);
    featureRegistry.register(DrawingFeature);
    featureRegistry.register(ModulationFeature);
    featureRegistry.register(WebcamFeature);
    featureRegistry.register(DebugToolsFeature);
    featureRegistry.register(EngineSettingsFeature);
};

// --- EXPORT TYPES ---
export * from './audioMod';
export * from './drawing/index';
export * from './modulation';
export * from './webcam';
export * from './debug_tools';
export * from './ao/index';
export * from './reflections/index';
export { NavigationState } from './navigation';
export { OpticsState } from './optics';
export { QualityState } from './quality';
export { GeometryState } from './geometry';
export { ColoringState } from './coloring';
export { TexturingState } from './texturing';
export { ColorGradingState } from './color_grading';
export { MaterialState } from './materials';
export { AtmosphereState } from './atmosphere/index'; 
export { DrosteState } from './droste';
export { LightingState } from './lighting/index';
export { CoreMathState } from './core_math';
export { WaterPlaneState } from './water_plane';
