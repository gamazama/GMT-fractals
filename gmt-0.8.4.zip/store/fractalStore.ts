
import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';
import { engine } from '../engine/FractalEngine';
import { FractalStoreState, FractalActions, Preset, FractalGraph, PipelineNode } from '../types';
import { createRendererSlice } from './slices/rendererSlice';
import { createCameraSlice } from './slices/cameraSlice';
import { createUISlice } from './slices/uiSlice';
import { createHistorySlice, HistorySlice } from './slices/historySlice';
import { createFeatureSlice } from './createFeatureSlice';
import { useAnimationStore } from './animationStore';
import { applyPresetState, sanitizeFeatureState } from '../utils/PresetLogic'; // Imported sanitizeFeatureState
import '../../formulas'; 
import { registerFeatures } from '../features';
import { featureRegistry } from '../engine/FeatureSystem';
import { topologicalSort, pipelineToGraph, isStructureEqual, isPipelineEqual } from '../utils/graphAlg';
import { JULIA_REPEATER_PIPELINE } from '../data/initialPipelines';
import { registry } from '../engine/FractalRegistry';
import { FractalEvents, FRACTAL_EVENTS } from '../engine/FractalEvents';
import { generateShareStringFromPreset, parseShareString } from '../utils/Sharing'; // Imported Sharing Utils
import { ShaderConfig } from '../engine/ShaderFactory';
import { detectEngineProfile, ENGINE_PROFILES } from '../features/engine/profiles';

registerFeatures();

// DYNAMIC INTERACTION LOCK SELECTOR
export const selectMovementLock = (s: FractalStoreState) => {
    // 1. Check Standard UI States
    if (s.isGizmoDragging || s.isPickingFocus || s.isPickingJulia || s.isSelectingRegion) return true;

    // 2. Iterate DDFS Features for Locks
    const features = featureRegistry.getAll();
    for (const feat of features) {
        if (feat.interactionConfig?.blockCamera && feat.interactionConfig.activeParam) {
            const slice = (s as any)[feat.id];
            if (slice && slice[feat.interactionConfig.activeParam]) {
                return true;
            }
        }
    }
    return false;
};

// HELPER: Convert Store State to Engine ShaderConfig
export const getShaderConfigFromState = (state: FractalStoreState): ShaderConfig => {
    const config: ShaderConfig = {
        formula: state.formula,
        pipeline: state.pipeline,
        graph: state.graph,
        pipelineRevision: state.pipelineRevision,
        msaaSamples: state.msaaSamples,
        previewMode: state.previewMode,
        maxSteps: state.quality?.maxSteps || 300,
        renderMode: state.renderMode,
        compilerHardCap: state.quality?.compilerHardCap || 500,
        shadows: state.lighting?.shadows
    };

    // Inject all feature states dynamically
    featureRegistry.getAll().forEach(feat => {
        const slice = (state as any)[feat.id];
        if (slice) {
            (config as any)[feat.id] = slice;
        }
    });

    return config;
};

export const useFractalStore = create<FractalStoreState & FractalActions & HistorySlice>()(subscribeWithSelector((set, get, api) => ({
    ...createRendererSlice(set, get, api),
    ...createCameraSlice(set, get, api),
    ...createUISlice(set, get, api),
    ...createHistorySlice(set, get, api),
    ...createFeatureSlice(set, get, api),

    formula: 'Mandelbulb', 
    
    projectSettings: {
        name: 'Mandelbulb',
        version: 0 // Start at 0, first save becomes 1
    },
    
    lastSavedHash: null,

    animations: [],
    liveModulations: {},
    pipeline: JULIA_REPEATER_PIPELINE, 
    graph: pipelineToGraph(JULIA_REPEATER_PIPELINE),
    pipelineRevision: 1,

    setFormula: (f, options: { skipDefaultPreset?: boolean } = {}) => {
        const s = get();
        const currentFormula = s.formula;
        if (currentFormula === f && f !== 'Modular') return;
        
        if (!options.skipDefaultPreset) {
            get().resetParamHistory();
        }

        // Smart Rename: Update project name if it matches the old formula (wasn't renamed by user)
        const currentName = s.projectSettings.name;
        let newName = currentName;
        if (currentName === currentFormula || currentName === 'Untitled' || currentName === 'Custom Preset') {
            newName = f;
        }

        set({ formula: f, projectSettings: { ...s.projectSettings, name: newName } });
        
        // Ensure pipeline data is sent along with formula update so engine can compile
        FractalEvents.emit(FRACTAL_EVENTS.CONFIG, { 
            formula: f,
            pipeline: s.pipeline,
            graph: s.graph
        });
        
        if (f !== 'Modular' && !options.skipDefaultPreset) {
            const def = registry.get(f);
            // Deep clone to ensure we don't mutate the registry default
            const formulaPreset: Preset = (def && def.defaultPreset) ? JSON.parse(JSON.stringify(def.defaultPreset)) : { formula: f };
            
            // --- SMART PROFILE PERSISTENCE ---
            // 1. Detect what profile the user is currently running (Lite, Balanced, Ultra, Fastest)
            const currentProfileKey = detectEngineProfile(get());
            
            // 2. If it's a specific named profile (not Custom), force that profile onto the new preset
            //    This ensures users on Mobile (Lite) stay on Lite when switching formulas.
            //    It avoids the heavy compile hit of switching to 'Balanced' (Default) then back to 'Lite'.
            if (currentProfileKey !== 'custom' && currentProfileKey !== 'balanced') {
                // @ts-ignore
                const profileConfig = ENGINE_PROFILES[currentProfileKey];
                if (profileConfig) {
                    if (!formulaPreset.features) formulaPreset.features = {};
                    
                    // Merge profile settings into the preset features
                    Object.entries(profileConfig).forEach(([featId, params]) => {
                        if (!formulaPreset.features![featId]) formulaPreset.features![featId] = {};
                        Object.assign(formulaPreset.features![featId], params);
                    });
                }
            }

            const lockScene = get().lockSceneOnSwitch;
            if (lockScene) {
                const current = get().getPreset(); 
                const merged: any = {
                    ...current, 
                    formula: f,
                    // We merge the formula's core math into the locked scene, 
                    // BUT we preserve the profile overrides we just calculated above.
                    features: { 
                        ...(formulaPreset.features || {}), 
                        coreMath: formulaPreset.features?.coreMath || current.features?.coreMath 
                    }
                };
                get().loadPreset(merged as Preset);
            } else {
                get().loadPreset(formulaPreset as Preset);
            }
        }
    },
    
    setProjectSettings: (s) => set((prev) => {
        const nextSettings = { ...prev.projectSettings, ...s };
        
        // If the name has changed, reset the versioning sequence
        // This ensures the user starts at v1 for the new name, avoiding "MyProject_v5" on first save
        if (s.name && s.name !== prev.projectSettings.name) {
            nextSettings.version = 0;
            return { 
                projectSettings: nextSettings,
                lastSavedHash: null 
            };
        }
        
        return { projectSettings: nextSettings };
    }),

    prepareExport: () => {
        const state = get();
        const currentSettings = state.projectSettings;
        
        // Get snapshot of current content
        const fullPreset = state.getPreset({ includeScene: true });
        
        // Remove 'version' and 'name' from the hash calculation
        const { version, name, ...content } = fullPreset as any;
        const currentHash = JSON.stringify(content);
        
        // 1. Initial Save (Version 0 -> 1) OR First save after load (Hash null)
        if (state.lastSavedHash === null || currentSettings.version === 0) {
            const nextVersion = Math.max(1, currentSettings.version + 1);
            set({ 
                lastSavedHash: currentHash,
                projectSettings: { ...currentSettings, version: nextVersion }
            });
            return nextVersion;
        }

        // 2. State has changed -> Increment
        if (state.lastSavedHash !== currentHash) {
            const nextVersion = currentSettings.version + 1;
            set({ 
                projectSettings: { ...currentSettings, version: nextVersion },
                lastSavedHash: currentHash
            });
            return nextVersion;
        }

        // 3. State unchanged -> Reuse version
        return currentSettings.version;
    },
    
    setAnimations: (v) => {
        const currentArr = get().animations;
        const nextArr = v.map((next) => {
            const current = currentArr.find(c => c.id === next.id);
            if (!current) return next;
            if (next.period !== current.period && next.period > 0) {
                const time = performance.now() / 1000;
                const newPhase = ((time / current.period) + current.phase - (time / next.period)) % 1.0;
                return { ...next, phase: (newPhase + 1.0) % 1.0 };
            }
            return next;
        });
        set({ animations: nextArr });
    },
    
    setLiveModulations: (v) => set({ liveModulations: v }),
    
    setGraph: (g) => {
        const sortedPipeline = topologicalSort(g.nodes, g.edges);
        const s = get();
        if (!isStructureEqual(s.pipeline, sortedPipeline)) {
            if (s.autoCompile) {
                const nextRev = s.pipelineRevision + 1;
                set({ graph: g, pipeline: sortedPipeline, pipelineRevision: nextRev });
                FractalEvents.emit(FRACTAL_EVENTS.CONFIG, { pipeline: sortedPipeline, graph: g, pipelineRevision: nextRev });
            } else set({ graph: g });
        } else {
            if (!isPipelineEqual(s.pipeline, sortedPipeline)) {
                set({ graph: g, pipeline: sortedPipeline });
                FractalEvents.emit(FRACTAL_EVENTS.CONFIG, { pipeline: sortedPipeline });
            } else set({ graph: g });
        }
    },

    setPipeline: (v) => { 
        const nextRev = get().pipelineRevision + 1;
        const newGraph = pipelineToGraph(v);
        set({ pipeline: v, graph: newGraph, pipelineRevision: nextRev }); 
        FractalEvents.emit(FRACTAL_EVENTS.CONFIG, { pipeline: v, graph: newGraph, pipelineRevision: nextRev }); 
    },
    
    refreshPipeline: () => { 
        const s = get();
        const sortedPipeline = topologicalSort(s.graph.nodes, s.graph.edges);
        const nextRev = s.pipelineRevision + 1; 
        set({ pipeline: sortedPipeline, pipelineRevision: nextRev }); 
        FractalEvents.emit(FRACTAL_EVENTS.CONFIG, { pipeline: sortedPipeline, graph: s.graph, pipelineRevision: nextRev }); 
    },

    getPreset: (options = { includeScene: true }) => { 
        const s = get(); 
        const animStore = useAnimationStore.getState();
        const includeScene = options.includeScene !== false;
        
        // Use current project settings
        const name = s.projectSettings.name;
        const version = s.projectSettings.version;
        
        const preset: Preset = { 
            version: version, 
            name: name, 
            formula: s.formula,
            features: {}
        };

        featureRegistry.getAll().forEach(feat => {
             const sliceState = (s as any)[feat.id];
             if (sliceState) {
                 if (!preset.features) preset.features = {};
                 preset.features[feat.id] = sanitizeFeatureState(sliceState);
             }
        });

        if (s.formula === 'Modular') {
            preset.pipeline = s.pipeline;
            preset.graph = s.graph;
        }

        if (includeScene) {
            const unified = engine.activeCamera ? 
                engine.virtualSpace.getUnifiedCameraState(engine.activeCamera) : 
                { position: s.cameraPos, rotation: s.cameraRot, sceneOffset: s.sceneOffset, targetDistance: s.targetDistance };

            preset.cameraPos = unified.position;
            preset.cameraRot = unified.rotation;
            preset.sceneOffset = unified.sceneOffset;
            preset.targetDistance = unified.targetDistance;
            
            preset.cameraMode = s.cameraMode;
            preset.lights = []; 
            preset.renderMode = s.renderMode;
            preset.quality = { aaMode: s.aaMode, aaLevel: s.aaLevel, msaa: s.msaaSamples, accumulation: s.accumulation };
            preset.animations = s.animations;
            preset.sequence = animStore.sequence;
            preset.duration = animStore.durationFrames;
        }
        return preset; 
    },
    
    loadPreset: (p) => { 
        get().resetParamHistory(); 
        
        // NORMALIZE FORMULA ID (Handle aliases)
        const def = registry.get(p.formula);
        const normalizedFormula = def ? def.id : p.formula;

        // Force setFormula without applying defaults, because we are about to overwrite everything
        set({ formula: normalizedFormula });

        // CRITICAL FIX: Explicitly notify Engine of formula change.
        // Zustand 'set' updates UI state but does not trigger the 'setFormula' action logic which contains the emit.
        FractalEvents.emit(FRACTAL_EVENTS.CONFIG, { formula: normalizedFormula });
        
        // Restore Project Settings
        let newName = p.name;
        if (!newName || newName === 'Untitled' || newName === 'Custom Preset') {
            newName = normalizedFormula;
        }

        // RESET VERSION TO 0 on load, so next save is 1
        set({ 
            projectSettings: { name: newName, version: 0 },
            lastSavedHash: null 
        });
        
        applyPresetState(p, set, get); 
        
        // Establish baseline hash for versioning (Loaded state = Clean state)
        setTimeout(() => {
             const loadedState = get().getPreset({ includeScene: true });
             const { version, name, ...content } = loadedState as any;
             set({ lastSavedHash: JSON.stringify(content) });
        }, 50);
    },

    getShareString: (options = { includeAnimations: true }) => {
        const state = get();
        const preset = state.getPreset({ includeScene: true });
        return generateShareStringFromPreset(preset, state.advancedMode, options);
    },

    loadShareString: (str: string) => {
        const decoded = parseShareString(str);
        if (decoded) {
            get().loadPreset(decoded);
            return true;
        }
        return false;
    }
})));

export const bindStoreToEngine = () => {
    const s = useFractalStore.getState();
    const update = (partial: any) => engine.setRenderState(partial);
    
    // Initial Sync
    update({
        isExporting: s.isExporting, 
        isBucketRendering: s.isBucketRendering,
        cameraMode: s.cameraMode,
        optics: s.optics,
        lighting: s.lighting,
        quality: s.quality, // Sync Quality
        bucketConfig: {
            bucketSize: s.bucketSize,
            bucketUpscale: s.bucketUpscale,
            convergenceThreshold: s.convergenceThreshold,
            accumulation: s.accumulation
        }
    });

    // Send full config to ConfigManager for compilation consistency
    FractalEvents.emit(FRACTAL_EVENTS.CONFIG, getShaderConfigFromState(s));

    // Subscriptions (Runtime)
    useFractalStore.subscribe(state => state.isExporting, (v) => update({ isExporting: v }));
    useFractalStore.subscribe(state => state.isBucketRendering, (v) => update({ isBucketRendering: v }));
    
    useFractalStore.subscribe(state => state.cameraMode, (v) => update({ cameraMode: v }));
    useFractalStore.subscribe(state => state.optics, (v) => update({ optics: v }));
    useFractalStore.subscribe(state => state.lighting, (v) => update({ lighting: v }));
    useFractalStore.subscribe(state => state.quality, (v) => update({ quality: v })); 

    // Bucket Config Sync
    const syncBucketConfig = () => {
        const cs = useFractalStore.getState();
        update({ 
            bucketConfig: { 
                bucketSize: cs.bucketSize, 
                bucketUpscale: cs.bucketUpscale,
                convergenceThreshold: cs.convergenceThreshold,
                accumulation: cs.accumulation
            } 
        });
    };
    useFractalStore.subscribe(state => state.bucketSize, syncBucketConfig);
    useFractalStore.subscribe(state => state.bucketUpscale, syncBucketConfig);
    useFractalStore.subscribe(state => state.convergenceThreshold, syncBucketConfig);
    useFractalStore.subscribe(state => state.accumulation, syncBucketConfig);

    // Watch Buffer Precision to trigger Pipeline Resize (reallocation)
    useFractalStore.subscribe(state => state.quality?.bufferPrecision, (v) => {
        if (engine.renderer) {
             const canvas = engine.renderer.domElement;
             // Calling resize checks the type internally and re-inits if changed
             engine.pipeline.resize(canvas.width, canvas.height);
        }
    });
    
    // Sync Lighting RenderMode changes to legacy RenderMode slice (for UI compatibility)
    // When a preset loads, it updates lighting.renderMode directly via applyPresetState.
    // We need to reflect this in state.renderMode so the UI dropdowns show the correct value.
    useFractalStore.subscribe(state => (state as any).lighting?.renderMode, (val) => {
        const mode = val === 1.0 ? 'PathTracing' : 'Direct';
        // Only update if changed to avoid loop (setRenderMode also updates lighting)
        if (useFractalStore.getState().renderMode !== mode) {
            useFractalStore.setState({ renderMode: mode });
        }
    });

    // Listen for Reverse Events (Engine -> UI)
    FractalEvents.on(FRACTAL_EVENTS.BUCKET_STATUS, ({ isRendering }) => {
        // Dispatch to Store
        useFractalStore.getState().setIsBucketRendering(isRendering);
    });
};
