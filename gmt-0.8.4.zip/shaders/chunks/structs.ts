
export const STRUCTS = `
// Structs removed for optimization. 
// Data is now passed via packed vec4s or raw float/vec3 parameters.
`;
